#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "arvore.h"
#include <queue>
#include <stack>

using namespace std;

Arv_bin* cria_arv(Nodo* raiz){
    Arv_bin* arv = (Arv_bin*) malloc(sizeof(Arv_bin));
    arv->raiz = raiz;
    return arv;
}

Nodo* cria_nodo(char info, Nodo* esq, Nodo* dir){
    Nodo* no = (Nodo*) malloc(sizeof(Nodo));
    no->info = info;
    no->esq = esq;
    no->dir = dir;
    return no;
}

void escolhe_ordem_arv(Arv_bin* arv, int num){
    switch (num){
    case 1:
        ordem_pre_fixa(arv->raiz);
        break;
    case 2:
        ordem_infixa(arv->raiz);
        break;
    case 3:
        ordem_pos_fixa(arv->raiz);
        break;
    }
}

void ordem_pre_fixa(Nodo* no){
    if(no != NULL){
        printf("%c", no->info);
        ordem_pre_fixa(no->esq);
        ordem_pre_fixa(no->dir);
    }
}

void ordem_infixa(Nodo* no){
    if(no != NULL){
        ordem_infixa(no->esq);
        printf("%c", no->info);
        ordem_infixa(no->dir);
    }
}

void ordem_pos_fixa(Nodo* no){
    if(no != NULL){
        ordem_pos_fixa(no->esq);
        ordem_pos_fixa(no->dir);
        printf("%c", no->info);
    }
}

void ordem_format(Nodo* no){
    if(no != NULL){
        printf("%c", no->info);
        printf("<");
        ordem_format(no->esq);
        printf(">");
        ordem_format(no->dir);
    }
}

void libera_arv(Arv_bin* raiz){
    libera_nodo(raiz->raiz);
    free(raiz);
}

void libera_nodo(Nodo* no){
    if(no != NULL){
        libera_nodo(no->esq);
        libera_nodo(no->dir);
        free(no);
    }
}

int pertence_arv(Nodo* raiz, char info){
    if(raiz == NULL){
        return 0;
    }
    if(raiz->info == info){
        return 1;
    }
    if(pertence_arv(raiz->esq, info)){
        return 1;
    }
    return pertence_arv(raiz->dir, info);
}

Nodo* busca_nodo(Nodo* raiz, char info){
    if(raiz == NULL) return NULL;
    if(raiz->info == info) return raiz;
    Nodo* no = busca_nodo(raiz->esq, info);
    if(no != NULL){
        return no;
    } else {
        return busca_nodo(raiz->dir, info);
    }
}

int arv_altura(Arv_bin* raiz){
    return arv_altura_no(raiz->raiz);

}

int max(int alt_esq, int alt_dir){
    return alt_esq > alt_dir ? alt_esq : alt_dir;
}

int arv_altura_no(Nodo* no){
    if(no == NULL){
        return -1;
    }
    int alt_esq = 1 + arv_altura_no(no->esq);
    int alt_dir = 1 + arv_altura_no(no->dir);
    return max(alt_esq, alt_dir);
}

int tamanho(Arv_bin* arv){
    int tam = conta_no(arv->raiz);

    return tam;
}

int conta_no(Nodo* no){
    if(no == NULL){
        return 0;
    }
    int cont = conta_no(no->esq) + conta_no(no->dir);
    return ++cont;
}

Arv_bin* cria_arv_espelho(Arv_bin* arv){
    Arv_bin* espelho_arv = (Arv_bin*) malloc(sizeof(Arv_bin));
    espelho_arv->raiz = cria_nodo(arv->raiz->info, arv->raiz->esq, arv->raiz->dir);
    espelho_arv->raiz->esq = cria_no_espelho(arv->raiz->dir);
    espelho_arv->raiz->dir = cria_no_espelho(arv->raiz->esq);

    return espelho_arv;
}

Nodo* cria_no_espelho(Nodo* original){
    if(original == NULL){
        return NULL;
    }
    Nodo* no = (Nodo*) malloc(sizeof(Nodo));

    no->esq = cria_no_espelho(original->dir);
    no->dir = cria_no_espelho(original->esq);
    no->info = original->info;

    return no;
}

void largura_arv(Arv_bin* a){
    queue<Nodo*> fila;
    fila.push(a->raiz);
    while(!fila.empty()){
        Nodo* p = fila.front();
        fila.pop();
        if(p){
            printf("%c", p->info);
            fila.push(p->esq);
            fila.push(p->dir);
        }
    }
}

void infixa_interativo(Arv_bin* arv){
    stack<Nodo*> pilha;
    Nodo* corr = NULL;
    pilha.push(arv->raiz);
    while(!pilha.empty()){
        corr = pilha.top();
        while(corr->esq != NULL){
            pilha.push(corr->esq);
            corr = pilha.top();
        }
        printf("%c", corr->info);
        pilha.pop();
        if(corr->dir != NULL){
            pilha.push(corr->dir);
        } else {
            if(!pilha.empty()){
                corr = pilha.top();
                printf("%c", corr->info);
                pilha.pop();
                if(corr->dir != NULL){
                    pilha.push(corr->dir);
                }
            }
        }
    }
}

void posfixa_interativo(Arv_bin* arv){
    stack<Nodo*> pilha1;
    stack<Nodo*> pilha2;
    Nodo* corr = NULL;

    pilha1.push(arv->raiz);
    while(!pilha1.empty()){
        corr = pilha1.top();
        pilha2.push(corr);
        pilha1.pop();
        if(corr->esq != NULL){
            pilha1.push(corr->esq);
        }
        if(corr->dir != NULL){
            pilha1.push(corr->dir);
        }
    }
    while(!pilha2.empty()){
        printf("%c", pilha2.top()->info);
        pilha2.pop();
    }
}

int conta_folhas_arv(Nodo* raiz){
    if(raiz == NULL){
        return 0;
    }
    if(raiz->esq == NULL && raiz->dir == NULL){
        return 1;
    }
    return conta_folhas_arv(raiz->esq) + conta_folhas_arv(raiz->dir);
}

int estritamente_binaria(Nodo* raiz){
    if((raiz->esq != NULL && raiz->dir == NULL) || (raiz->esq == NULL && raiz->dir != NULL)){
        return 1;
    }
    if(raiz->esq == NULL && raiz->dir == NULL){
        return 0;
    }

    return estritamente_binaria(raiz->esq) + estritamente_binaria(raiz->dir);
}

int completa_bin(Nodo* raiz){
    int h = pow(2,arv_altura_no(raiz));
    int folhas = conta_folhas_arv(raiz);
    if(h == folhas){
        return 1;
    } else {
        return 0;
    }
}


