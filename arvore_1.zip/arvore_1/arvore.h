#ifndef ARVORE_H
#define ARVORE_H

typedef struct nodo{
    char info;
    struct nodo* esq;
    struct nodo* dir;
} Nodo;

typedef struct arv_bin{
    Nodo* raiz;
} Arv_bin;

Arv_bin* cria_arv(Nodo* raiz);
Nodo* cria_nodo(char info, Nodo* esq, Nodo* dir);
void escolhe_ordem_arv(Arv_bin* arv, int num);
void ordem_pre_fixa(Nodo* no);
void ordem_infixa(Nodo* no);
void ordem_pos_fixa(Nodo* no);
void libera_arv(Arv_bin* raiz);
void libera_nodo(Nodo* no);
int pertence_arv(Nodo* raiz, char info);
Nodo* busca_nodo(Nodo* raiz, char info);
int arv_altura(Arv_bin* raiz);
int max(int alt_esq, int alt_dir);
int arv_altura_no(Nodo* no);
Arv_bin* cria_arv_espelho(Arv_bin* arv);
Nodo* cria_no_espelho(Nodo* original);
int tamanho(Arv_bin* arv);
int conta_no(Nodo* no);
void largura_arv(Arv_bin* a);
void ordem_format(Nodo* no);
void infixa_interativo(Arv_bin* arv);
void posfixa_interativo(Arv_bin* arv);
int conta_folhas_arv(Nodo* raiz);
int estritamente_binaria(Nodo* raiz);
int completa_bin(Nodo* raiz);





#endif // ARVORE_H
