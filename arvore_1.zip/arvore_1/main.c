#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"


// LER LIVRO DA PAG 186 - 194

int main()
{
    Arv_bin* arv = cria_arv(cria_nodo('A',
                                      cria_nodo('B',
                                                cria_nodo('D', NULL, NULL),
                                                cria_nodo('E', NULL, NULL)
                                                ),
                                      cria_nodo('C', NULL, NULL)
                                      )
                            );

    escolhe_ordem_arv(arv, 1);
    printf("\n");
    printf("Pertence: %d\n", pertence_arv(arv->raiz, 'C'));
    Nodo* result_busca = busca_nodo(arv->raiz, 'C');
    printf("BUSCA: %c\n", result_busca->info);
    int altura_arv = arv_altura(arv);
    printf("Altura arvore: %d\n", altura_arv);
    int tam = tamanho(arv);
    printf("Quant. Nos: %d \n", tam);
    Arv_bin* arv_espelho = cria_arv_espelho(arv);
    escolhe_ordem_arv(arv_espelho, 1);

    libera_arv(arv);
    libera_arv(arv_espelho);
}
