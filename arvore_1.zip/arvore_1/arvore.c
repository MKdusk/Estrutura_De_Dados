#include <stdlib.h>
#include <stdio.h>
#include "arvore.h"

Arv_bin* cria_arv(Nodo* raiz){
    Arv_bin* arv = (Arv_bin*) malloc(sizeof(Arv_bin));
    arv->raiz = raiz;
    return arv;
}

Nodo* cria_nodo(char info, Nodo* esq, Nodo* dir){
    Nodo* no = (Nodo*) malloc(sizeof(Nodo));
    no->info = info;
    no->esq = esq;
    no->dir = dir;
    return no;
}

void escolhe_ordem_arv(Arv_bin* arv, int num){
    switch (num){
    case 1:
        ordem_pre_fixa(arv->raiz);
        break;
    case 2:
        ordem_infixa(arv->raiz);
        break;
    case 3:
        ordem_pos_fixa(arv->raiz);
        break;
    }
}

void ordem_pre_fixa(Nodo* no){
    if(no != NULL){
        printf("%c", no->info);
        ordem_pre_fixa(no->esq);
        ordem_pre_fixa(no->dir);
    }
}

void ordem_infixa(Nodo* no){
    if(no != NULL){
        ordem_infixa(no->esq);
        printf("%c", no->info);
        ordem_infixa(no->dir);
    }
}

void ordem_pos_fixa(Nodo* no){
    if(no != NULL){
        ordem_pos_fixa(no->esq);
        ordem_pos_fixa(no->dir);
        printf("%c", no->info);
    }
}

void libera_arv(Arv_bin* raiz){
    libera_nodo(raiz->raiz);
    free(raiz);
}

void libera_nodo(Nodo* no){
    if(no != NULL){
        libera_nodo(no->esq);
        libera_nodo(no->dir);
        free(no);
    }
}

int pertence_arv(Nodo* raiz, char info){
    if(raiz == NULL){
        return 0;
    }
    if(raiz->info == info){
        return 1;
    }
    if(pertence_arv(raiz->esq, info)){
        return 1;
    }
    return pertence_arv(raiz->dir, info);
}

Nodo* busca_nodo(Nodo* raiz, char info){
    if(raiz == NULL) return NULL;
    if(raiz->info == info) return raiz;
    Nodo* no = busca_nodo(raiz->esq, info);
    if(no != NULL){
        return no;
    } else {
        return busca_nodo(raiz->dir, info);
    }
}

int arv_altura(Arv_bin* raiz){
    return arv_altura_no(raiz->raiz);

}

int max(int alt_esq, int alt_dir){
    return alt_esq > alt_dir ? alt_esq : alt_dir;
}

int arv_altura_no(Nodo* no){
    if(no == NULL){
        return -1;
    }
    int alt_esq = 1 + arv_altura_no(no->esq);
    int alt_dir = 1 + arv_altura_no(no->dir);
    return max(alt_esq, alt_dir);
}

int tamanho(Arv_bin* arv){
    int tam = conta_no(arv->raiz);

    return tam;
}

int conta_no(Nodo* no){
    if(no == NULL){
        return 0;
    }
    int cont = conta_no(no->esq) + conta_no(no->dir);
    return ++cont;
}

Arv_bin* cria_arv_espelho(Arv_bin* arv){
    Arv_bin* espelho_arv = (Arv_bin*) malloc(sizeof(Arv_bin));
    espelho_arv->raiz = cria_nodo(arv->raiz->info, arv->raiz->esq, arv->raiz->dir);
    espelho_arv->raiz->esq = cria_no_espelho(arv->raiz->dir);
    espelho_arv->raiz->dir = cria_no_espelho(arv->raiz->esq);

    return espelho_arv;
}

Nodo* cria_no_espelho(Nodo* original){
    if(original == NULL){
        return NULL;
    }
    Nodo* no = (Nodo*) malloc(sizeof(Nodo));

    no->esq = cria_no_espelho(original->dir);
    no->dir = cria_no_espelho(original->esq);
    no->info = original->info;

    return no;
}

