#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"

// LER LIVRO DA PAG 186 - 194

int main()
{
    Arv_bin* arv = cria_arv(cria_nodo('A',
                                      cria_nodo('B',
                                                cria_nodo('D', NULL, NULL),
                                                cria_nodo('E', NULL, NULL)
                                                ),
                                      cria_nodo('C',
                                                cria_nodo('F', NULL, NULL),
                                                cria_nodo('G', NULL, NULL))
                                      )
                            );


    printf("=====ARVORE=====\n");

    printf("PRE FIXA: ");
    escolhe_ordem_arv(arv, 1);
    printf("\nINFIXA: ");
    escolhe_ordem_arv(arv, 2);
    printf("\nPOS FIXA: ");
    escolhe_ordem_arv(arv, 3);

    printf("\n\nFOMATADO: ");
    ordem_format(arv->raiz);


    printf("\n");
    printf("\nPERTENCE: %d\n", pertence_arv(arv->raiz, 'C'));

    Nodo* result_busca = busca_nodo(arv->raiz, 'C');
    printf("\nBUSCA: %c\n", result_busca->info);

    int altura_arv = arv_altura(arv);
    printf("\nALTURA: %d\n", altura_arv);
    int tam = tamanho(arv);

    printf("\nLARGURA: ");
    largura_arv(arv);

    printf("\n\nQuant. de Nos: %d", tam);
    Arv_bin* arv_espelho = cria_arv_espelho(arv);

    printf("\n\nESPELHADO: ");
    escolhe_ordem_arv(arv_espelho, 1);

    printf("\n\nINFIXA INTERATIVO: ");
    infixa_interativo(arv);

    printf("\n\nPOSFIXA INTERATIVO: ");
    posfixa_interativo(arv);

    int folhas = conta_folhas_arv(arv->raiz);
    printf("\n\nQuant. de Folhas: %d", folhas);

    int est_bin = estritamente_binaria(arv->raiz);
    printf("\n\nEH ESTRITAMENTE BINARIA: ");
    if(est_bin > 0){
        printf("NAO");
    } else {
        printf("SIM");
    }

    printf("\n\nEH UMA ARVORE COMPLETA: ");
    if(completa_bin(arv->raiz)){
        printf("SIM");
    } else {
        printf("NAO");
    }

    libera_arv(arv);
    libera_arv(arv_espelho);
}
